angular.module('app.controllers', [])
  
.controller('loginCtrl', function($scope) {

})
   
.controller('digipassCtrl', function($scope) {

})
 